<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');
	$this->load->view('template/default/user/paths/header-view');
	//$this->load->view('template/default/user/paths/top-header-view');
		echo $contents;
	 $this->load->view('template/default/user/paths/footer-view');
 ?>
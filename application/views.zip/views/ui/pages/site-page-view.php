<section class="py-5">
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-8 offset-2 py-5">
                <div style="border: 0"  class="card shadow">
                    <div class="card-body">
                        <h2><?php echo $page['page_name']; ?></h2>
                        <?php echo $page['page_content']; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
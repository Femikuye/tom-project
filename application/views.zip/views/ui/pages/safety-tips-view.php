<section class="py-5">
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-8 offset-2 py-5">
                <div style="border: 0"  class="card shadow">
                    <div class="card-body">
                        <h2>SAFETY TIPS</h2>
                        <p>Tormami.com manually review any ads placed on our website hence any ads we found inappropriate will be deleted without prior notice.</p>
                        <h4>Take note of these safety precaution in any transaction.</h4>
                        <p>Do not disburse money prior to receiving or seeing a promised ITEM.</p>
                        <p>Do not meet buyer/Seller in an isolated are. Bars, Restaurants, Coffee shops, Shopping mall e.t.c is advisable.</p>
                        <p>Do not meet buyer/Seller Alone.</p>
                        <p>Take some time to thoroughly examine a product ask necessary questions and be satisfied before making any payment.</p>
                        <p>Be careful of visa contactors.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
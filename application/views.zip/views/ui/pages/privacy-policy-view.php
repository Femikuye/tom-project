<section class="py-5">
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-8 offset-2 py-5">
                <div style="border: 0"  class="card shadow">
                    <div class="card-body">
                        <h2>PRIVACY POLICY</h2>
                        <p>Thank you for accessing the Tormami.com website (“Site”) operated by Tormami. We respect your privacy as users and want to protect your personal information. To learn more, please read this Privacy Policy carefully.
Your privacy is important to us, so To Sell It has created this Privacy Policy to explain how your information is protected, collected and used. This Privacy Policy applies to our web sites, and web sites which we operate on behalf of our partners (the "Sites"). This Privacy Policy may be updated from time to time. You can always review the most current version here. By using the Sites, you consent to the terms and conditions of this Privacy Policy and are aware that our policies may evolve in the future. If there is a conflict between our Terms of Use governing your use of the Sites and this Privacy Policy, the Terms of Use control.
</p>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
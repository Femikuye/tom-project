<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card border text-center">
                            <div class="card-body">
                                <h5>Account Confirmation</h5>
                                <p><?php echo isset($msg) ? $msg : 'Nothing To display' ?></p>
                                 <div id="formFooter">
      								<a class="underlineHover" href="<?php echo base_url(); ?>">Go to the Site</a>
    								</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>